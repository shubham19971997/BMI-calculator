import 'package:flutter/material.dart';
import 'constants.dart';

class BottomButton extends StatelessWidget {
  BottomButton({@required this.buttontitle,@required this.ontap});
  final Function ontap;
  final String buttontitle;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        child: Center(child: Text(buttontitle,style: klargebutton,)),
        padding: EdgeInsets.only(bottom: 10.0),
        margin: EdgeInsets.only(top: 10.0),
        width: double.infinity,
        height: kBottomcontainerheight,
        decoration: BoxDecoration(color: Color(0xFFE43C83), borderRadius: BorderRadius.only(topLeft: Radius.circular(50.0))) ,
      ),
    );
  }
}