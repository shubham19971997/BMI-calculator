import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'icon_content.dart';
import 'reusable_card.dart';
import 'constants.dart';
import 'result.dart';
import 'bottombutton.dart';
import 'calculator_brain.dart';

enum Gender
{
  male,
  female,
}



class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {

  Gender selectedGender;
  int height = 180;
  int weight = 60;
  int age = 25;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI CALCULATOR'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(child: Row(
            children: <Widget>[
              Expanded(
                  child: ReusableCard(
                    onpress:()
                    {
                      setState(() {
                        selectedGender = Gender.male;
                      });
                      } ,
                   colour: selectedGender==Gender.male?kActivecardcolor:kInactivecardcolor,
                    childCard: iconcontent(icon: FontAwesomeIcons.mars,
                    label: "MALE",
                  )
                ),
              ),
              Expanded(child: ReusableCard(
                onpress: ()
                {
                  setState(() {
                    selectedGender = Gender.female;
                  });
                },
                colour: selectedGender==Gender.female?kActivecardcolor:kInactivecardcolor,
                childCard: iconcontent(icon: FontAwesomeIcons.venus, label: 'FEMALE',),
              ),
              ),
              ],
          ),
          ),
          Expanded(child: ReusableCard(
              colour: kActivecardcolor,
              childCard: Column(mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text("HEIGHT",style: kLabeltextstyle,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: <Widget>[
                      Text(
                        height.toString(),style: knumberStyle,
                      ),
                      Text(
                        "cm",style: kLabeltextstyle,
                      )
                    ],
                  ),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(

                      activeTrackColor: Colors.white,
                        inactiveTrackColor: Color(0xFF8D8E98),
                      thumbColor: Color(0xFFEB1555),
                      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 11.0),
                          overlayColor: Color(0x29EB1555) ,
                          overlayShape: RoundSliderOverlayShape(overlayRadius: 22.0)
                    ),
                    child: Slider(
                      value: height.toDouble(),
                      min: 120.0,
                      max: 220.0,


                      onChanged: (double newValue){
                        setState(() {
                          height = newValue.round();
                        });
                        },
                    ),
                  ),
                ],
              ) ,
          ),

          ),
          Expanded(child: Row(
            children: <Widget>[
             Expanded(child: ReusableCard(
                 colour: kActivecardcolor,
               childCard: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: <Widget>[
                   Text("WEIGHT", style: kLabeltextstyle,),
                   Text(weight.toString(),
                     style: knumberStyle,
                   ),
                   Row(mainAxisAlignment: MainAxisAlignment.center,
                     children: <Widget>[
                       Roundiconbuton(
                         OnPressed: (){
                           setState(() {
                             weight--;
                           });
                         },
                         icon: FontAwesomeIcons.minus,

                       ),
                       SizedBox(width: 10.0 ,),
                       Roundiconbuton(
                         OnPressed: (){
                           setState(() {
                             weight++;
                           });
                         },
                         icon: FontAwesomeIcons.plus,
                       ),
                     ],
                   )
                 ],

               ),
             ),
    ),
             Expanded(child: ReusableCard(
               colour: kActivecardcolor,
               childCard: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: <Widget>[
                   Text("AGE", style: kLabeltextstyle,),
                   Text(age.toString(),
                     style: knumberStyle,
                   ),
                   Row(mainAxisAlignment: MainAxisAlignment.center,
                     children: <Widget>[
                       Roundiconbuton(
                         OnPressed: (){
                           setState(() {
                             age--;
                           });
                         },
                         icon: FontAwesomeIcons.minus,

                       ),
                       SizedBox(width: 10.0 ,),
                       Roundiconbuton(
                         OnPressed: (){
                           setState(() {
                             age++;
                           });
                         },
                         icon: FontAwesomeIcons.plus,
                       ),
                     ],
                   )
                 ],

               ),
             ),
    ),
    ],
          )
    ),
          BottomButton(buttontitle: "CALCULATE",
          ontap: (){
            CalculatorBrain calculate = CalculatorBrain(height: height, weight: weight );

            Navigator.push(context,MaterialPageRoute(builder: (context)=>Resultpage(
              bmires: calculate.calculateBMI(),
              restest: calculate.getresult() ,
              interpre: calculate.getintrpretation(),

            ),
            ),
            );
            }
              ,)
    ],
      ),
    );
  }
}


















class Roundiconbuton extends StatelessWidget {
  Roundiconbuton({@required this.icon,@required this.OnPressed});
  final Function OnPressed;
  final IconData icon;
  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      child: Icon(icon) ,
      onPressed: OnPressed,
      elevation: 6.0,
      constraints: BoxConstraints.tightFor(
        width: 50.0,
        height: 50.0,
      ),
      shape: CircleBorder(),
      fillColor: Color(0xFF4C4F5E),
    );
  }
}




