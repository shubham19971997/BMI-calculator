import 'package:flutter/material.dart';
const kLabeltextstyle = TextStyle(fontSize: 18.0,color: Color(0xFF8D8E98));
const kBottomcontainerheight = 65.0;
const kActivecardcolor = Color(0xFF1D1E33);
const kInactivecardcolor = Color(0xFF111328);
const knumberStyle =  TextStyle(fontSize: 50,fontWeight: FontWeight.w900);

const klargebutton = TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold );

const ktitletextstyle = TextStyle(
  fontSize: 45.0,
  fontWeight: FontWeight.bold
);
const kresulttextStyle = TextStyle(
  color: Color(0xFF24D876),
      fontSize: 18.0,
   fontWeight: FontWeight.bold
);

const kbmitextstyle = TextStyle(
  fontSize: 80.0,
  fontWeight: FontWeight.bold

);

const kbodytextstyle = TextStyle(
  fontSize: 18.0
);