import 'package:bmi_calculator/constants.dart';
import 'package:flutter/material.dart';
import 'reusable_card.dart';
import 'bottombutton.dart';

class Resultpage extends StatelessWidget {
  Resultpage({@required this.bmires,@required this.interpre,@required this.restest});

  final String bmires;
  final String restest;
  final String interpre;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI CALCULATOR") ,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(
            child: Container(
              alignment: Alignment.bottomLeft,
              padding: EdgeInsets.all(15.0),
              child: Text("Your Result",style: ktitletextstyle,),

            ),
          ),
          Expanded(
            flex: 5,
            child: ReusableCard(colour: kActivecardcolor,
              childCard: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(restest.toUpperCase(),style: kresulttextStyle,),
                  Text(
                    bmires, style: kbmitextstyle,
                  ),
                  Text(interpre,style: kbodytextstyle,textAlign: TextAlign.center,)
                ],
              ),
            ),
          ),
          BottomButton(buttontitle: "RE-CALCULATE",ontap:(){
            Navigator.pop(context);
          },)
        ],
      ),
    );
  }
}
